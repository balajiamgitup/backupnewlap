﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OA.Domain.Settings
{
    public class ApplicationDetail
    {
        public string ApplicationName { get; set; }
        public string Description { get; set; }
        public string ContactWebsite { get; set; }
        public string LicenseDetail { get; set; }
    }
}
