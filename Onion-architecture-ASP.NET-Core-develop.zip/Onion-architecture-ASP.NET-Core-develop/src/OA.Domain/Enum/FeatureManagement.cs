﻿namespace OA.Domain.Enum
{
    public enum FeatureManagement
    {
        EnableEmailService
    }
}
