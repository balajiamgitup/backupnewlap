﻿namespace OA.Service.Contract
{
    public interface IAuthenticatedUserService
    {
        string UserId { get; }
    }
}
