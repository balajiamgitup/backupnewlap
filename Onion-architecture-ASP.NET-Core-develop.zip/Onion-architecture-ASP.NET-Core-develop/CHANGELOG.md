# Changelog

All notable changes to this project will be documented in this file.

Version will be updated as it is released to Microsoft Marketplace

## Version 1.3

### Added API Versioning

* Added API versioning
* Fixed bug related to update 

## Version 1.2

### Fixed bug

* Fixed bug

## Version 1.0

### Code refactored

* Removed data layer and refactored 

## Version 0.6

### Added feature

* Swagger
* CQRS Pattern
* Loggings - seriLog

## Version 0.5

### Added feature

* Email feature

## Version 0.2 - 0.4

### Fixed issue related to Project template

* Project template

## Version 0.1 - 26-Jun-2020 

### Initial release

* Application is implemented on Onion architecture
* API
* Entityframework Core
* Expection handling
* Automapper
* Unit testing via NUnit
* Integration testing via NUnit

