﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.Repository
{
    public class GenericRepository<T> :IGenericRepository<T> where T : class
    {

        private readonly RestDbContext restDbContext;

        public GenericRepository(RestDbContext restDbContext)
        {
            this.restDbContext = restDbContext;
        }

        public async Task<T> AddAsync(T entity)
        {
            try
            {
                await restDbContext.AddAsync(entity);
                await restDbContext.SaveChangesAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<T> DeleteAsync(int id)
        {
            try
            {
                var entity = await restDbContext.Set<T>().FindAsync(id);

                if (entity == null)
                {
                    return null;
                }

                restDbContext.Set<T>().Remove(entity);
                await restDbContext.SaveChangesAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            try
            {
                return await restDbContext.Set<T>().ToListAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<T> GetAsync(int id)
        {
            try
            {
                return await restDbContext.Set<T>().FindAsync(id);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<T> UpdateAsync(int id, T entity)
        {
            try
            {
                var updatedEntity = await restDbContext.Set<T>().FindAsync(id);
                if (updatedEntity == null)
                {
                    return null;
                }

                restDbContext.Set<T>().Update(entity);
                await restDbContext.SaveChangesAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}
