﻿using DocumentFormat.OpenXml.Drawing.Charts;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Resaturent.UI.Tests.MockData;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using Restaurent.UI.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
//using Restaurent.Domain.Entities;

namespace Resaturent.UI.Tests.Controller
{
    public class TestOrderContoller
    {
        [Fact]
        public async Task GetAllOrder_ShouldReturn200Status()
        {
            var logger=new Mock<ILogger>();
            //Arrange
            var service = new Mock<IOrderService>();
            //map the methods 
            service.Setup(x=>x.GetAllOrderAsync()).ReturnsAsync(OrderMockData.GetOrders());
            //system under test call controller and pass objects 
            var sut=new OrderController(service.Object, logger.Object);
            //Act calling testing method from controller 
            var result=await sut.GetAllOrderAsync();

            //Aeert test the result 
            result.GetType().Should().Be(typeof(OkObjectResult));
            (result as OkObjectResult).StatusCode.Should().Be(200);
        }

    }
}
