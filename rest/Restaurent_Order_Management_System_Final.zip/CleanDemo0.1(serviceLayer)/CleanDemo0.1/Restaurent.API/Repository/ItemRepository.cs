﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Restaurent.Application;
using Restaurent.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Restaurent.Infrastructure.Repository
{
    public class ItemRepository : IitemRepository
    {

        private readonly RestDbContext restDbContext;
      

        public ItemRepository(RestDbContext restDbContext)
        {
            this.restDbContext = restDbContext;
      
        }

        [HttpGet]
        public async Task<IEnumerable<Item>> GetAllAsync()
        {
            return await restDbContext.item.ToListAsync();
        }
    }
}