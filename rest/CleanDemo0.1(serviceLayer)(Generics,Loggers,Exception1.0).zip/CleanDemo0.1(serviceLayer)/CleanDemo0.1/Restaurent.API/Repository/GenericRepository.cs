﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.Repository
{
    public class GenericRepository<T> :IGenericRepository<T> where T : class
    {

        private readonly RestDbContext restDbContext;

        public GenericRepository(RestDbContext restDbContext)
        {
            this.restDbContext = restDbContext;
        }

        public async Task<T> AddAsync(T entity)
        {
            await restDbContext.AddAsync(entity);
            await restDbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<T> DeleteAsync(int id)
        {
            var entity = await restDbContext.Set<T>().FindAsync(id);

            if (entity == null)
            {
                return null;
            }

            restDbContext.Set<T>().Remove(entity);
            await restDbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await restDbContext.Set<T>().ToListAsync();
        }

        public async Task<T> GetAsync(int id)
        {
            return await restDbContext.Set<T>().FindAsync(id);
        }

        public async Task<T> UpdateAsync(int id, T entity)
        {
            var updatedEntity = await restDbContext.Set<T>().FindAsync(id);
            /*  if (existingOrderItem != null)
              {
                  existingOrderItem.quantity = orders.quantity;
                  existingOrderItem.itemId = orders.itemId;
                  existingOrderItem.orderId = orders.orderId;
                  await restDbContext.SaveChangesAsync();

                  return existingOrderIte;
              } */
            restDbContext.Set<T>().Update(entity);
            await restDbContext.SaveChangesAsync();
            return entity;
        }
    }
}
