﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.Repository
{
    public class OrderItemRepository : GenericRepository<OrderItem>, IOrderItemRepository
    {

        /*  private readonly RestDbContext restDbContext;
          //private DbSet<T> entities;

          public OrderItemRepository(RestDbContext restDbContext)
          {
              this.restDbContext = restDbContext;
              // entities = restDbContext.Set<T>();
          }

          public async Task<OrderItem> AddAsync(OrderItem orderItems)
          {
              //orderItems.orderItemId = Guid.NewGuid();
              await restDbContext.AddAsync(orderItems);
              await restDbContext.SaveChangesAsync();
              return orderItems;
          }

          public async Task<OrderItem> DeleteAsync(int orderItemId)
          {
              var existingOrderItem = await restDbContext.orderItem.FindAsync(orderItemId);

              if (orderItemId == null)
              {
                  return null;
              }

              restDbContext.orderItem.Remove(existingOrderItem);
              await restDbContext.SaveChangesAsync();
              return existingOrderItem;
          }

          public async Task<IEnumerable<OrderItem>> GetAllOrderItemAsync()
          {
              return await restDbContext.orderItem.ToListAsync();
          }

          public async Task<OrderItem> GetOrdeItemAsync(int orderItemId)
          {
              return await restDbContext.orderItem.FirstOrDefaultAsync(x => x.orderItemId == orderItemId);
          }

          public async Task<OrderItem> UpdateAsync(int orderItemId, OrderItem orders)
          {
              var existingOrderItem = await restDbContext.orderItem.FirstOrDefaultAsync(x => x.orderItemId == orderItemId);
              if (existingOrderItem != null)
              {
                  existingOrderItem.quantity = orders.quantity;
                  existingOrderItem.itemId = orders.itemId;
                  existingOrderItem.orderId = orders.orderId;
                  await restDbContext.SaveChangesAsync();

                  return existingOrderItem;
              }
              return null;
          } */
        public OrderItemRepository(RestDbContext restDbContext) : base(restDbContext)
        {
        }
    }
}
