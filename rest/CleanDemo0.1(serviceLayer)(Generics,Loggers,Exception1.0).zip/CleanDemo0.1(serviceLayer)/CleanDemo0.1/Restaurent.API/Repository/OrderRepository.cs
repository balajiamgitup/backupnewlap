﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.Context;

namespace Restaurent.Infrastructure.Repository
{
    public class OrderRepository : GenericRepository<Order>, IOrderRepository
    {

        /*    private readonly RestDbContext restDbContext;
               //private DbSet<T> entities;

               public OrderRepository(RestDbContext restDbContext)
               {
                   this.restDbContext = restDbContext;
                   // entities = restDbContext.Set<T>();
               }


              public async Task<Order> AddAsync(Order orders)
               {
                   //orders.orderId = Guid.NewGuid();
                   await restDbContext.AddAsync(orders);
                   await restDbContext.SaveChangesAsync();
                   return orders;
               }

               public async Task<Order> DeleteAsync(int orderId)
               {
                   var existingOrder = await restDbContext.orders.FindAsync(orderId);

                   if (orderId == null)
                   {
                       return null;
                   }

                   restDbContext.orders.Remove(existingOrder);
                   await restDbContext.SaveChangesAsync();
                   return existingOrder;
               }

               public async Task<IEnumerable<Order>> GetAllOrderAsync()
               {

                 return await restDbContext.orders.ToListAsync();
               }

               public async Task<Order> GetOrdeAsync(int orderId)
               {
                   return await restDbContext.orders.FirstOrDefaultAsync(x => x.orderId == orderId);
               }

               public async Task<Order> UpdateAsync(int orderId, Order orders)
               {
                   var existingOrder = await restDbContext.orders.FirstOrDefaultAsync(x => x.orderId == orderId);
                   if (existingOrder != null)
                   {
                       existingOrder.userId = orders.userId;
                       existingOrder.tablenumber = orders.tablenumber;
                       existingOrder.statusId = orders.statusId;
                       await restDbContext.SaveChangesAsync();

                       return existingOrder;
                   }
                   return null;
               } */
        public OrderRepository(RestDbContext restDbContext) : base(restDbContext)
        {
        }
    }
}
