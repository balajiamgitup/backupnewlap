﻿namespace Restaurent.Infrastructure.Extensions
{
    public class ExceptionMiddlewareExtensionsBase
    {
    }
}