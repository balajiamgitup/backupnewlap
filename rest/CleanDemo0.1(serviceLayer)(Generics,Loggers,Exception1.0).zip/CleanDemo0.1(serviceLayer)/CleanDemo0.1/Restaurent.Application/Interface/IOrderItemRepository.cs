﻿using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Interface
{
    public interface IOrderItemRepository : IGenericRepository<OrderItem>
    {

   /*     Task<IEnumerable<OrderItem>> GetAllOrderItemAsync();

        Task<OrderItem> GetOrdeItemAsync(int orderItemId);
        Task<OrderItem> AddAsync(OrderItem orderItems);

        Task<OrderItem> DeleteAsync(int orderItemId);

        Task<OrderItem> UpdateAsync(int orderItemId, OrderItem orders); */
    }
}
