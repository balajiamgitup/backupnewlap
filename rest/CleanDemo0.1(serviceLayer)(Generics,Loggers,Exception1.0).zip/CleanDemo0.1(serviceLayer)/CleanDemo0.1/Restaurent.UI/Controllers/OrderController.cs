﻿using AutoMapper;
using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Restaurent.Application;
using Restaurent.Application.Interface;
using Restaurent.Infrastructure.Context;
using Restaurent.Infrastructure.Repository;
using Restaurent.Domain.Entities;
using Order = Restaurent.Domain.Entities.Order;
using DocumentFormat.OpenXml.Spreadsheet;

namespace Restaurent.UI.Controllers
{


    [ApiController]
    [Route("[controller]")]
    public class OrderController : Controller
    {

        private Application.Interface.ILogger _logger;

        private readonly IOrderService iorderService;
        public OrderController(IOrderService iorderService, Application.Interface.ILogger logger)
        {
            this.iorderService = iorderService;
            this._logger = logger;
            // entities = restDbContext.Set<T>();
        }

        [HttpGet]
        public async Task<IActionResult> GetAllOrderAsync()

        {
            
                _logger.LogInfo("Fetching all the Orders from the DB");
                var orders = await iorderService.GetAllOrderAsync();
                _logger.LogInfo($"Returning {orders.Count()} Orders.");

                return Ok(orders);
            

           /* catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            } */
        }


        [HttpGet]
        [Route("{id:int}")]
        [ActionName("GetOrderAsync")]
        public async Task<IActionResult> GetOrderAsync(int id)
        {
            {
                var order = await iorderService.GetOrdeAsync(id);
                if (order == null)
                {
                    return NotFound();
                }
    
                return Ok(order);
            }

        }


        [HttpPost]
       // [Authorize]
        public async Task<IActionResult> AddOrderAsync([FromBody] Order addOrderRequest)
        {
            //Validate request
            //   var orders = await iorderService.AddAsync(addOrderRequest);

            //request to domain model
            var order = new Order()
            {
               // orderId = new Guid(),
             tablenumber= addOrderRequest.tablenumber,
                statusId=addOrderRequest.statusId,
                userId=addOrderRequest.userId,


            };

            //pass details to repository

            order = await iorderService.AddAsync(order);
            //Convert back to DTO

         
           //    return Ok(OrderDTO);

            return CreatedAtAction(nameof(GetOrderAsync), new { id = order.orderId }, order);
        }


        [HttpPut]
     //   [Authorize(Roles = "waiter")]
        [Route("{orderId:int}")]
        public async Task<IActionResult> UpdateOrder([FromRoute] int orderId, [FromBody]Order updateOrder)
        {
            // convert DTO to Domain model

            var order = new Order()
            {
                userId = updateOrder.userId,
                tablenumber = updateOrder.tablenumber,
                statusId = updateOrder.statusId,

            };

            //Update Item using repository

            order = await iorderService.UpdateAsync(orderId, order);


            //if null then notfound
            if (order == null)
            {
                return NotFound();
            }
      

            //return ok responce
            return Ok(order);


        }




        [HttpDelete]
      //  [Authorize(Roles = "waiter")]
        [Route("{orderId:int}")]
        public async Task<IActionResult> DeleteOrderAsync(int orderId)
        {
            //call Repo

            var order = await iorderService.DeleteAsync(orderId);

            if (order == null)
            {
                return NotFound();
            }

           // var walkDTO = mapper.Map<Models.DTO.Order>(orderDomain);

            return Ok(order);
        }
    }
}
