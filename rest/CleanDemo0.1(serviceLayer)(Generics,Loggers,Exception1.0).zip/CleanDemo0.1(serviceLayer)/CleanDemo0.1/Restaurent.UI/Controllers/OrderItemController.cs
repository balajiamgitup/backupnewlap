﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurent.Application.Interface;
using Restaurent.Application.Services;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.Repository;

namespace Restaurent.UI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderItemController : Controller
    {


        private readonly IOrderItemService iorderItemService;
        public OrderItemController(IOrderItemService iorderItemService)
        {
            this.iorderItemService = iorderItemService;
            // entities = restDbContext.Set<T>();
        }



        [HttpGet]
        public async Task<IActionResult> GetAllOrderItemsAsync()
        {
            var orderItem = await iorderItemService.GetAllOrderItemAsync();

            return Ok(orderItem);
        }
        [HttpGet]
        [Route("{id:int}")]
        [ActionName("GetOrderItemsAsync")]
        public async Task<IActionResult> GetOrderItemsAsync(int id)
        {
            {
                var orderItem = await iorderItemService.GetOrderItemAsync(id);
                if (orderItem == null)
                {
                    return NotFound();
                }
     
                return Ok(orderItem);
            }

        }


        [HttpPost]
        // [Authorize]
        public async Task<IActionResult> AddOrderItemsAsync([FromBody] OrderItem addOrderItemRequest)
        {

          
            var orderItem = new OrderItem()
            {
                // orderId = new Guid(),
                orderItemId = addOrderItemRequest.orderItemId,
                quantity = addOrderItemRequest.quantity,
                itemId = addOrderItemRequest.itemId,
                orderId = addOrderItemRequest.orderId


            };

            orderItem = await iorderItemService.AddAOrdersync(orderItem);
           
          
            return CreatedAtAction(nameof(GetOrderItemsAsync), new { id = orderItem.orderId }, orderItem);
        }


        [HttpPut]
        [Route("{orderItemId:int}")]
        public async Task<IActionResult> UpdateOrderItem([FromRoute] int orderItemId, [FromBody]OrderItem updateOrderItem)
        {
       

            var orderItem = new OrderItem()
            {
                quantity = updateOrderItem.quantity,
                itemId = updateOrderItem.itemId,
                orderId = updateOrderItem.orderId,

            };

            //Update Item using repository

            orderItem = await iorderItemService.UpdateOrderItemAsync(orderItemId, orderItem);


            //if null then notfound
            if (orderItem == null)
            {
                return NotFound();
            }

           // return orderItem != null ? Ok(orderItem) : return NotFound();
            return Ok(orderItem);


        }


        [HttpDelete]
        [Route("{orderItemId:int}")]
        public async Task<IActionResult> DeleteOrderItemAsync(int orderItemId)
        {
       
            var orderitem = await iorderItemService.DeleteOrderItemAsync(orderItemId);

            if (orderitem == null)
            {
                return NotFound();
            }

        //    var walkDTO = mapper.Map<Models.DTO.OrderItem>(orderitemDomain);

            return Ok(orderitem);
        }

    }
}
