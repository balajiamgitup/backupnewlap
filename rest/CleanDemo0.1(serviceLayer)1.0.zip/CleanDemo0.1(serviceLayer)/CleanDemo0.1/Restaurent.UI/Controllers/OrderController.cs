﻿using AutoMapper;
using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Restaurent.Application;
using Restaurent.Application.Interface;
using Restaurent.Infrastructure.Context;
using Restaurent.Infrastructure.Repository;
using Restaurent.Domain.Entities;
using Order = Restaurent.Domain.Entities.Order;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Office2010.Excel;

namespace Restaurent.UI.Controllers
{


    [ApiController]
    [Route("[controller]")]
    public class OrderController : Controller
    {

        private Application.Interface.ILogger _logger;

        private readonly IOrderService iorderService;
        public OrderController(IOrderService iorderService, Application.Interface.ILogger logger)
        {
            this.iorderService = iorderService;
            this._logger = logger;
       
        }

        [HttpGet]
        public async Task<IActionResult> GetAllOrderAsync()

        {
            try
            {
                _logger.LogInfo("Fetching all the Orders from the DB");
                var orders = await iorderService.GetAllOrderAsync();
                _logger.LogInfo($"Returning {orders.Count()} Orders.");

                return Ok(orders);

            }
          catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            } 
        }


        [HttpGet]
        [Route("{id:int}")]
        [ActionName("GetOrderAsync")]
        public async Task<IActionResult> GetOrderAsync(int id)
        {
            
                try
                {
                    _logger.LogInfo($"Getting OrderID : {id} Order");
                    var order = await iorderService.GetOrdeAsync(id);
                    if (order == null)
                    {
                        _logger.LogError("ID is not found");
                        return NotFound();
                    }
                    return Ok(order);
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Something went wrong: {ex}");
                    return StatusCode(500, "Internal server error");
                }

        }

        [HttpPost]
        // [Authorize]
        public async Task<IActionResult> AddOrderAsync([FromBody] Order addOrderRequest)
        {

            try
            {
                _logger.LogInfo($"Adding Orders to DB");
                var order = new Order()
                {
                    // orderId = new Guid(),
                    tablenumber = addOrderRequest.tablenumber,
                    statusId = addOrderRequest.statusId,
                    userId = addOrderRequest.userId,


                };

             

                order = await iorderService.AddAsync(order);
          

                return CreatedAtAction(nameof(GetOrderAsync), new { id = order.orderId }, order);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut]
     //   [Authorize(Roles = "waiter")]
        [Route("{orderId:int}")]
        public async Task<IActionResult> UpdateOrder([FromRoute] int orderId, [FromBody]Order updateOrder)
        {
       

            try
            {

                var order = new Order()
                {
                    userId = updateOrder.userId,
                    tablenumber = updateOrder.tablenumber,
                    statusId = updateOrder.statusId,

                };

             
                _logger.LogInfo($"Upadted OrderID : {orderId} Orders");
                order = await iorderService.UpdateAsync(orderId, order);

             
              
                    if (order == null)
                    {
                    _logger.LogError($"{orderId} NOT FOUND ");
                    return NotFound();
                    
                }

     
                return Ok(order);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }

        }




        [HttpDelete]
      //  [Authorize(Roles = "waiter")]
        [Route("{orderId:int}")]
        public async Task<IActionResult> DeleteOrderAsync(int orderId)
        {
            //call Repo
            try
            {

                _logger.LogInfo($"Deleted OrderID :  {orderId} Orders");

                var order = await iorderService.DeleteAsync(orderId);

                if (order == null)
                {
                    _logger.LogError($"{orderId} NOT FOUND ");
                    return NotFound();
                }


                return Ok(order);
            }
            catch(Exception ex)
            {

                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
