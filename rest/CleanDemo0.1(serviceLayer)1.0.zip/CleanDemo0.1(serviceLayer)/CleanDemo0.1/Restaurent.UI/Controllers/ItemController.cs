﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurent.Application;

namespace Restaurent.UI.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class ItemController : Controller
    {



        private readonly IitemService itemService;

        public ItemController(IitemService itemService)
        {
            this.itemService = itemService;
  

        }
        [HttpGet]
        public   async Task<IActionResult> GetAllitemAsync()
        {
            var items = await itemService.GetAllAsync();

            return Ok(items);
        }
    }
}
