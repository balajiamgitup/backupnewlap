﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application.Interface;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly RestDbContext _context;
        private readonly Dictionary<Type, object> _repositories = new Dictionary<Type, object>();

        public UnitOfWork(RestDbContext context)
        {
            _context = context;
        }

        public RestDbContext Context
        {
            get { return _context; }
        }

        public async Task<int> CommitAsync()
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    var result = await _context.SaveChangesAsync();
                    transaction.Commit();
                    return result;
                }
                catch (Exception)
                {
     
                    transaction.Rollback();
                    throw;
                }
            }
        }
        public void Dispose()
        {
          //  throw new NotImplementedException();
        }
    }
}
